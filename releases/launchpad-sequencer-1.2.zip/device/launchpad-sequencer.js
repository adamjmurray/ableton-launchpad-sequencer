function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest();
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread();
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) arr2[i] = arr[i];

    return arr2;
  }
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArray(iter) {
  if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter);
}

function _iterableToArrayLimit(arr, i) {
  if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) {
    return;
  }

  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance");
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance");
}

var logToMaxConsoleWith = function logToMaxConsoleWith(log) {
  return function () {
    for (var _len = arguments.length, values = new Array(_len), _key = 0; _key < _len; _key++) {
      values[_key] = arguments[_key];
    }

    values.forEach(function (message) {
      if (message && message.toString) {
        var s = message.toString();

        if (s.indexOf("[object ") >= 0) {
          s = JSON.stringify(message);
        }

        log(s);
      } else if (message === null) {
        log("<null>");
      } else {
        log(message);
      }
    });
    log("\n");
  };
};

var MaxConsole = function MaxConsole() {
  _classCallCheck(this, MaxConsole);

  this.log = logToMaxConsoleWith(function (string) {
    return post(string);
  });
  this.error = logToMaxConsoleWith(function (string) {
    return error(string);
  });
};

// modulo function that always returns a positive number
Number.prototype.mod = function (divisor) {
  var value = this % divisor;
  return value >= 0 ? value : value + divisor;
};

Array.prototype.fill = function (value) {
  for (var i = 0; i < this.length; i++) {
    this[i] = value;
  }

  return this;
};

Array.prototype.includes = function (value) {
  for (var i = 0; i < this.length; i++) {
    if (this[i] === value) return true;
  }

  return false;
};

var GUI_COLOR = Object.freeze({
  // Max's LCD object uses the format [R,G,B] in 0-255 range
  BACKGROUND: Object.freeze([27, 27, 27]),
  PATTERN_START_END: Object.freeze([200, 200, 255]),
  // the color of the bracket marking the first and last step in the pattern:
  STEP_VALUE: Object.freeze([// maps step values to GUI colors
  Object.freeze([150, 150, 150]), // off
  Object.freeze([0, 255, 0]), // green
  Object.freeze([255, 255, 0]), // yellow
  Object.freeze([255, 127, 0]), // orange
  Object.freeze([255, 0, 0]), // red
  Object.freeze([80, 130, 200]) // current step (TODO: why doesn't the launchpad colors use this format i.e. put this at end of array?)
  ]),
  SEQUENCER_STEP: Object.freeze([80, 130, 200]) // TODO: can we replace the last item in STEP_VALUE above?

});

var lpColor = function lpColor(green, red) {
  return 16 * green + red + 4;
}; // + 4 ensures writes to both buffers in case the Launchpad is in double buffering mode


var LP_OFF = lpColor(0, 0);
var LP_GREEN = lpColor(3, 0);
var LP_YELLOW = lpColor(3, 2);
var LP_ORANGE = lpColor(2, 3);
var LP_RED = lpColor(0, 3);
var LP_INACTIVE_GREEN = lpColor(2, 0);
var LP_INACTIVE_YELLOW = lpColor(2, 1);
var LP_INACTIVE_ORANGE = lpColor(1, 2);
var LP_INACTIVE_RED = lpColor(0, 2);
var LP_SEQUENCER_STEP = lpColor(1, 1);
var LP_TRACK_COLOR = lpColor(1, 2);
var LP_PATTERN_COLOR = lpColor(2, 0);
var LP_MUTE_COLOR = lpColor(0, 3);
var LP_INACTIVE_MUTE_COLOR = lpColor(0, 1);
var LAUNCHPAD_COLOR = Object.freeze({
  OFF: LP_OFF,
  GREEN: LP_GREEN,
  YELLOW: LP_YELLOW,
  ORANGE: LP_ORANGE,
  RED: LP_RED,
  INACTIVE_GREEN: LP_INACTIVE_GREEN,
  INACTIVE_YELLOW: LP_INACTIVE_YELLOW,
  INACTIVE_ORANGE: LP_INACTIVE_ORANGE,
  INACTIVE_RED: LP_INACTIVE_RED,
  SEQUENCER_STEP: LP_SEQUENCER_STEP,
  // color for current sequencer step, regardless of value
  TRACK_COLOR: LP_TRACK_COLOR,
  PATTERN_COLOR: LP_PATTERN_COLOR,
  MUTE_COLOR: LP_MUTE_COLOR,
  INACTIVE_MUTE_COLOR: LP_INACTIVE_MUTE_COLOR,
  // mute color when the track/pattern is not selected (maybe rename this DESELECTED_MUTE_COLOR?)
  STEP_VALUES: Object.freeze([LP_OFF, LP_GREEN, LP_YELLOW, LP_ORANGE, LP_RED]),
  // maps step value to color
  INACTIVE_STEPS: Object.freeze([LP_OFF, LP_INACTIVE_GREEN, LP_INACTIVE_YELLOW, LP_INACTIVE_ORANGE, LP_INACTIVE_RED]) // maps step value to color in "pattern ops mode" for steps outside the pattern's start/end range

});
var DEFAULT = Object.freeze({
  STEP_DURATION: '1/16',
  MODULATION_SUMMING_MODE: 'add',
  MODULATION_SLEW: 0,
  PATTERN_TYPES: Object.freeze([// maps pattern index to the default type for that pattern
  'velocity', 'duration', 'aftertouch', 'modulation', 'random mute', 'gate', 'gate', 'gate']),
  PITCH: 60,
  VELOCITY: 70,
  GATE: 0.9,
  GATE_MODE: 'pitch',
  GATE_SUMMING_MODE: 'add',
  VALUE: 1,
  SAVE_DELAY: 2000,
  SCALE_ROOT: 0,
  SCALE_OFFSETS: Object.freeze([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]) // full chromatic scale

});
var GESTURE = Object.freeze({
  SELECT: 'select',
  DOUBLE_PRESS: 'double press',
  TRIPLE_PRESS: 'triple press'
});
var GUI = Object.freeze({
  STEP_WIDTH: 18,
  BUTTON_WIDTH: 12
});
var LAUNCHPAD = Object.freeze({
  TOP_ROW_CC: 104
});
var MIDI = Object.freeze({
  TRANSPORT_STOP: 123 // MIDI CC number

});
var MODE = Object.freeze({
  SEQUENCER: 'SEQUENCER',
  PATTERN_EDIT: 'PATTERN_EDIT',
  GATE: Object.freeze({
    PITCH: 'pitch',
    VELOCITY: 'velocity'
  }),
  GATE_SUMMING: Object.freeze({
    ADD: 'add',
    AVERAGE: 'avg',
    HIGHEST: 'high',
    LOWEST: 'low',
    MULTI: 'multi',
    RANDOM: 'rand',
    RANDOM_WITH_0: 'rand+0'
  })
});
var NUMBER_OF = Object.freeze({
  GATES: 3,
  // number of gate-type patterns in a track
  TRACKS: 4,
  // number of tracks in the device
  PATTERNS: 8,
  // number of patterns per track
  STEPS: 64,
  // number of sequencer steps per pattern
  ROWS: 8,
  // number of steps per row in the pattern grid
  COLUMNS: 8,
  // number of steps per column in the pattern grid
  STEP_VALUES: 5 // number of step values (off, green, yellow, orange, and red)

});
var OUTLET = Object.freeze({
  NOTE: 0,
  CC: 1,
  AFTERTOUCH: 2,
  LAUNCHPAD_NOTE: 3,
  LAUNCHPAD_CC: 4,
  LAUNCHPAD_RAPID_UPDATE: 5,
  GUI: 6,
  STORAGE: 7
});
var PATTERN = Object.freeze({
  // maps pattern types to pattern indexes
  VELOCITY: 0,
  DURATION: 1,
  AFTERTOUCH: 2,
  MODULATION: 3,
  MUTE: 4,
  GATE1: 5,
  GATE2: 6,
  GATE3: 7
}); // Maps step values to device values

var STEP_VALUE = Object.freeze({
  OFF: 0,
  GATE_DURATION: Object.freeze([null, 1, 2, 4, 8]),
  DURATION: Object.freeze([1, 2, 4, 8, 16]),
  OCTAVES: Object.freeze([null, 12, 24, -12, -24])
});
var STORAGE = Object.freeze({
  DURATION: 'duration',
  SCALE_OFFSETS: 'scale',
  SCALE_ROOT: 'root',
  MODULATION_SUMMING_MODE: 'modsum',
  MODULATION_SLEW: 'modslew',
  TRACKS: 'tracks',
  PITCH: 'pitch',
  VELOCITY: 'velocity',
  GATE: 'gate',
  GATE_MODE: 'gatemode',
  MULTIPLIER: 'multiplier',
  GATE_SUMMING_MODE: 'gatesum',
  MUTE: 'mute',
  PATTERNS: 'patterns',
  STEPS: 'steps',
  START: 'start',
  END: 'end'
});

var DURATION = STORAGE.DURATION,
    SCALE_OFFSETS = STORAGE.SCALE_OFFSETS,
    SCALE_ROOT = STORAGE.SCALE_ROOT,
    MODULATION_SUMMING_MODE = STORAGE.MODULATION_SUMMING_MODE,
    MODULATION_SLEW = STORAGE.MODULATION_SLEW,
    TRACKS = STORAGE.TRACKS,
    PITCH = STORAGE.PITCH,
    VELOCITY = STORAGE.VELOCITY,
    GATE = STORAGE.GATE,
    GATE_MODE = STORAGE.GATE_MODE,
    GATE_SUMMING_MODE = STORAGE.GATE_SUMMING_MODE,
    MULTIPLIER = STORAGE.MULTIPLIER,
    MUTE = STORAGE.MUTE,
    PATTERNS = STORAGE.PATTERNS,
    STEPS = STORAGE.STEPS,
    START = STORAGE.START,
    END = STORAGE.END; // Maybe this could all go into View and Controller can call the store*() methods directly

var StorageView = /*#__PURE__*/function () {
  function StorageView() {
    _classCallCheck(this, StorageView);
  }

  _createClass(StorageView, [{
    key: "storeDuration",
    value: function storeDuration(duration) {
      outlet(OUTLET.STORAGE, DURATION, duration);
    }
  }, {
    key: "storeScaleOffsets",
    value: function storeScaleOffsets(offsets) {
      outlet(OUTLET.STORAGE, SCALE_OFFSETS, offsets);
    }
  }, {
    key: "storeScaleRoot",
    value: function storeScaleRoot(root) {
      outlet(OUTLET.STORAGE, SCALE_ROOT, root);
    }
  }, {
    key: "storeModulationSummingMode",
    value: function storeModulationSummingMode(mode) {
      outlet(OUTLET.STORAGE, MODULATION_SUMMING_MODE, mode);
    }
  }, {
    key: "storeModulationSlew",
    value: function storeModulationSlew(slew) {
      outlet(OUTLET.STORAGE, MODULATION_SLEW, slew);
    }
  }, {
    key: "storeTrackPitch",
    value: function storeTrackPitch(trackIndex, pitch) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, PITCH, pitch);
    }
  }, {
    key: "storeTrackVelocity",
    value: function storeTrackVelocity(trackIndex, velocity) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, VELOCITY, velocity);
    }
  }, {
    key: "storeTrackGate",
    value: function storeTrackGate(trackIndex, gate) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, GATE, gate);
    }
  }, {
    key: "storeTrackGateMode",
    value: function storeTrackGateMode(trackIndex, mode) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, GATE_MODE, mode);
    }
  }, {
    key: "storeTrackGateSummingMode",
    value: function storeTrackGateSummingMode(trackIndex, mode) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, GATE_SUMMING_MODE, mode);
    }
  }, {
    key: "storeTrackMultiplier",
    value: function storeTrackMultiplier(trackIndex, multiplier) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, MULTIPLIER, multiplier);
    }
  }, {
    key: "storeTrackMute",
    value: function storeTrackMute(trackIndex, mute) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, MUTE, mute);
    }
  }, {
    key: "storePatternSteps",
    value: function storePatternSteps(trackIndex, patternIndex, steps) {
      if (this._saveAfterDelay) {
        this._saveAfterDelay.cancel();

        this._saveAfterDelay = null;
      }

      outlet(OUTLET.STORAGE, TRACKS, trackIndex, PATTERNS, patternIndex, STEPS, steps);
    }
  }, {
    key: "storePatternStepsAfterDelay",
    value: function storePatternStepsAfterDelay(trackIndex, patternIndex, steps) {
      var _this = this;

      // use a delay to avoid creating undo state on every interaction
      if (this._saveAfterDelay) {
        this._saveAfterDelay.cancel();
      }

      this._saveAfterDelay = new Task(function () {
        return _this.storePatternSteps(trackIndex, patternIndex, steps);
      });

      this._saveAfterDelay.schedule(DEFAULT.SAVE_DELAY);
    }
  }, {
    key: "storePatternStart",
    value: function storePatternStart(trackIndex, patternIndex, startIndex) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, PATTERNS, patternIndex, START, startIndex);
    }
  }, {
    key: "storePatternEnd",
    value: function storePatternEnd(trackIndex, patternIndex, endIndex) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, PATTERNS, patternIndex, END, endIndex);
    }
  }, {
    key: "storePatternMute",
    value: function storePatternMute(trackIndex, patternIndex, mute) {
      outlet(OUTLET.STORAGE, TRACKS, trackIndex, PATTERNS, patternIndex, MUTE, mute);
    }
  }, {
    key: "storeAll",
    value: function storeAll(model) {
      var _this2 = this;

      this.storeDuration(model.globalStepDuration);
      this.storeScaleOffsets(model.scale.offsets);
      this.storeScaleRoot(model.scale.root);
      this.storeModulationSummingMode(model.modulationSummingMode);
      this.storeModulationSlew(model.modulationSlew);
      model.tracks.forEach(function (track, trackIndex) {
        _this2.storeTrackPitch(trackIndex, track.pitch);

        _this2.storeTrackVelocity(trackIndex, track.velocity);

        _this2.storeTrackGate(trackIndex, track.gate);

        _this2.storeTrackGateMode(trackIndex, track.gateMode);

        _this2.storeTrackGateSummingMode(trackIndex, track.gateSummingMode);

        _this2.storeTrackMultiplier(trackIndex, track.durationMultiplier);

        _this2.storeTrackMute(trackIndex, track.mute);

        track.patterns.forEach(function (pattern, patternIndex) {
          _this2.storePatternSteps(trackIndex, patternIndex, pattern.steps);

          _this2.storePatternStart(trackIndex, patternIndex, pattern.startStepIndex);

          _this2.storePatternEnd(trackIndex, patternIndex, pattern.endStepIndex);

          _this2.storePatternMute(trackIndex, patternIndex, pattern.mute);
        });
      });
    }
  }]);

  return StorageView;
}();

var PressGesture = /*#__PURE__*/function () {
  function PressGesture() {
    _classCallCheck(this, PressGesture);

    this.reset();
  }

  _createClass(PressGesture, [{
    key: "reset",
    value: function reset() {
      this._previousIndex = NaN;
      this._repeatPressCount = 0;
    }
  }, {
    key: "interpretPress",
    value: function interpretPress(index) {
      if (index === this._previousIndex) {
        this._repeatPressCount++; // Note, if you let this go to 6 presses without a reset(), it will only return DOUBLE_PRESS
        // If you want to watch for triple presses, reset() after each one occurs.

        if (this._repeatPressCount % 2 === 0) {
          return GESTURE.DOUBLE_PRESS;
        }

        if (this._repeatPressCount % 3 === 0) {
          return GESTURE.TRIPLE_PRESS;
        }
      } else {
        this._previousIndex = index;
        this._repeatPressCount = 1;
        return GESTURE.SELECT;
      }
    }
  }]);

  return PressGesture;
}();

var RangeSelectionGesture = /*#__PURE__*/function () {
  function RangeSelectionGesture() {
    _classCallCheck(this, RangeSelectionGesture);

    this._pressedIndexes = [];
  }

  _createClass(RangeSelectionGesture, [{
    key: "reset",
    value: function reset() {
      this._pressedIndexes.fill(false);
    }
  }, {
    key: "interpretRangeSelection",
    value: function interpretRangeSelection(index, isPressed) {
      this._pressedIndexes[index] = isPressed;

      if (this._pressedIndexes.filter(function (i) {
        return i;
      }).length < 2) {
        // less than 2 buttons pressed, so there is no range
        return;
      }

      return [this._minPressedIndex, this._maxPressedIndex];
    }
  }, {
    key: "_minPressedIndex",
    get: function get() {
      var indexes = this._pressedIndexes;

      for (var i = 0; i < indexes.length; i++) {
        if (indexes[i]) {
          return i;
        }
      }
    }
  }, {
    key: "_maxPressedIndex",
    get: function get() {
      var indexes = this._pressedIndexes;

      for (var i = indexes.length - 1; i >= 0; i--) {
        if (indexes[i]) {
          return i;
        }
      }
    }
  }]);

  return RangeSelectionGesture;
}();

var DURATION$1 = STORAGE.DURATION,
    SCALE_OFFSETS$1 = STORAGE.SCALE_OFFSETS,
    SCALE_ROOT$1 = STORAGE.SCALE_ROOT,
    MODULATION_SUMMING_MODE$1 = STORAGE.MODULATION_SUMMING_MODE,
    MODULATION_SLEW$1 = STORAGE.MODULATION_SLEW,
    TRACKS$1 = STORAGE.TRACKS,
    PITCH$1 = STORAGE.PITCH,
    VELOCITY$1 = STORAGE.VELOCITY,
    GATE$1 = STORAGE.GATE,
    GATE_MODE$1 = STORAGE.GATE_MODE,
    GATE_SUMMING_MODE$1 = STORAGE.GATE_SUMMING_MODE,
    MULTIPLIER$1 = STORAGE.MULTIPLIER,
    MUTE$1 = STORAGE.MUTE,
    PATTERNS$1 = STORAGE.PATTERNS,
    STEPS$1 = STORAGE.STEPS,
    START$1 = STORAGE.START,
    END$1 = STORAGE.END;

var xyToIndex = function xyToIndex(x, y) {
  return x + y * NUMBER_OF.COLUMNS;
};

var Controller = /*#__PURE__*/function () {
  function Controller(model, view) {
    _classCallCheck(this, Controller);

    this._model = model;
    this._view = view;
    this._storage = new StorageView();
    this._topButtonGesture = new PressGesture();
    this._rightButtonGesture = new PressGesture();
    this._gridButtonGesture = new RangeSelectionGesture();
    this._patternStepsClipboard = null;
    this._patternStepsUndo = null;
  } // Render any transient view states that are not persisted and won't be restored by setModel()


  _createClass(Controller, [{
    key: "initViews",
    value: function initViews() {
      this._view.renderTrackIndex();

      this._view.renderPatternIndex();

      this._view.renderValue();
    }
  }, {
    key: "refreshViews",
    value: function refreshViews() {
      this._view.render();
    }
  }, {
    key: "reset",
    value: function reset() {
      this._model.reset();

      this._topButtonGesture.reset();

      this._rightButtonGesture.reset();

      this._gridButtonGesture.reset();

      this._heldTopButton = false;

      this._view.render();

      this._storage.storeAll(this._model);
    }
  }, {
    key: "setModel",
    value: function setModel(data) {
      switch (data[0]) {
        case DURATION$1:
          return this.setDuration(data[1], false);

        case SCALE_OFFSETS$1:
          return this.setScaleOffsets(data.slice(1), false);

        case SCALE_ROOT$1:
          return this.setScaleRoot(data[1], false);

        case MODULATION_SUMMING_MODE$1:
          return this.setModulationSummingMode(data[1], false);

        case MODULATION_SLEW$1:
          return this.setModulationSlew(data[1], false);

        case TRACKS$1:
          var trackIndex = data[1];

          switch (data[2]) {
            case PITCH$1:
              return this.setTrackPitch(data[3], trackIndex, false);

            case VELOCITY$1:
              return this.setTrackVelocity(data[3], trackIndex, false);

            case GATE$1:
              return this.setTrackGate(data[3], trackIndex, false);

            case GATE_MODE$1:
              return this.setTrackGateMode(data[3], trackIndex, false);

            case MULTIPLIER$1:
              return this.setTrackMultiplier(data[3], trackIndex, false);

            case GATE_SUMMING_MODE$1:
              return this.setTrackGateSummingMode(data[3], trackIndex, false);

            case MUTE$1:
              return this.setTrackMute(data[3], trackIndex, false);

            case PATTERNS$1:
              var patternIndex = data[3];

              switch (data[4]) {
                case STEPS$1:
                  return this.setPatternSteps(data.slice(5), trackIndex, patternIndex, false);

                case START$1:
                  return this.setPatternStart(data[5], trackIndex, patternIndex, false);

                case END$1:
                  return this.setPatternEnd(data[5], trackIndex, patternIndex, false);

                case MUTE$1:
                  return this.setPatternMute(data[5], trackIndex, patternIndex, false);

                default:
                  console.log("ERROR in setModel(). Unexpected data[4] \"".concat(data[4], "\""));
              }

              return;

            default:
              console.log("ERROR in setModel(). Unexpected data[4] \"".concat(data[2], "\""));
          }

          return;

        default:
          console.log("ERROR in setModel(). Unexpected data[0] \"".concat(data[0], "\""));
      }
    }
  }, {
    key: "handleTransportStop",
    value: function handleTransportStop() {
      this.handleClockTick(-1); // this avoids grid lights turning off that should stay on when "all notes off" happens:

      this._view.renderGrid(); // Make modulation and aftertouch values output on the first step when the transport starts again:


      this._prevAftertouch = null;
      this._prevModulation = null;
    }
  }, {
    key: "handleTrackNote",
    value: function handleTrackNote(pitch, velocity) {
      this._model.scale.toggle(pitch, velocity);

      this._view.renderScale(this._model.scale);
    }
  }, {
    key: "handleTrackCC",
    value: function handleTrackCC(cc) {
      if (cc === MIDI.TRANSPORT_STOP) {
        this.handleTransportStop();
      }
    }
  }, {
    key: "handleLaunchpadCC",
    value: function handleLaunchpadCC(cc, value) {
      if (cc === MIDI.TRANSPORT_STOP) {
        this.handleTransportStop();
      } else {
        this._handleLaunchpadTopButton(cc - LAUNCHPAD.TOP_ROW_CC, value > 0);
      }
    }
  }, {
    key: "handleLaunchpadNote",
    value: function handleLaunchpadNote(pitch, velocity) {
      var x = pitch % 16;
      var y = Math.floor(pitch / 16);

      if (x > 7) {
        this._handleLaunchpadRightButton(y, velocity > 0);
      } else {
        this._handleLaunchpadGridButton(x, y, velocity > 0);
      }
    }
  }, {
    key: "_handleLaunchpadTopButton",
    value: function _handleLaunchpadTopButton(index, isPressed) {
      if (isPressed) {
        if (this._model.mode === MODE.PATTERN_EDIT) {
          var gesture = this._topButtonGesture.interpretPress(index);

          switch (index) {
            case 0:
              this.shiftPatternUp();
              break;

            case 1:
              this.shiftPatternDown();
              break;

            case 2:
              this.shiftPatternLeft();
              break;

            case 3:
              this.shiftPatternRight();
              break;

            case 4:
              this.reversePattern();
              break;

            case 5:
              if (gesture === GESTURE.DOUBLE_PRESS) {
                this._undoPatternStepsChange();
              } else {
                this._recordPatternStepsForUndo();

                this.randomizePattern();
              }

              break;

            case 6:
              if (gesture === GESTURE.SELECT) {
                this.copyPatternSteps();
              } else if (gesture === GESTURE.DOUBLE_PRESS) {
                this._recordPatternStepsForUndo();

                this.clearPattern();
              } else {
                this._undoPatternStepsChange();
              }

              break;

            case 7:
              if (gesture === GESTURE.DOUBLE_PRESS) {
                this._undoPatternStepsChange();
              } else {
                this._recordPatternStepsForUndo();

                this.pastePatternSteps();
              }

              break;
          }
        } else {
          if (index <= 3) {
            switch (this._topButtonGesture.interpretPress(index)) {
              case GESTURE.SELECT:
                this.selectTrack(index);
                break;

              case GESTURE.TRIPLE_PRESS:
                this.setTrackMute(!this._model.selectedTrack.mute);

                this._topButtonGesture.reset();

                break;
            }
          } else {
            this.selectOrToggleValue(index - 3);
          }
        }
      }

      this._heldTopButton = isPressed;

      this._rightButtonGesture.reset();
    }
  }, {
    key: "_handleLaunchpadRightButton",
    value: function _handleLaunchpadRightButton(index, isPressed) {
      var model = this._model;

      if (isPressed) {
        if (model.mode === MODE.PATTERN_EDIT) {
          if (!this._heldTopButton) {
            model.mode = MODE.SEQUENCER;
            this.selectPattern(index, {
              forceRender: true
            });
          }
        } else {
          switch (this._rightButtonGesture.interpretPress(index)) {
            case GESTURE.SELECT:
              this.selectPattern(index);
              break;

            case GESTURE.TRIPLE_PRESS:
              if (this._heldTopButton) {
                model.mode = MODE.PATTERN_EDIT;

                this._gridButtonGesture.reset();

                this._view.render();
              } else {
                this.setPatternMute(!model.selectedPattern.mute);
              }

              this._rightButtonGesture.reset();

              break;
          }
        }
      }

      this._topButtonGesture.reset();
    }
  }, {
    key: "_handleLaunchpadGridButton",
    value: function _handleLaunchpadGridButton(x, y, isPressed) {
      var stepIndex = xyToIndex(x, y);

      if (this._model.mode === MODE.PATTERN_EDIT) {
        var range = this._gridButtonGesture.interpretRangeSelection(stepIndex, isPressed);

        if (range) {
          var _this$_model$selected;

          (_this$_model$selected = this._model.selectedPattern).setRange.apply(_this$_model$selected, _toConsumableArray(range));

          this._view.renderGrid();
        }
      } else if (isPressed) {
        this.setStepToValue(stepIndex, this._model.selectedValue);
      }

      this._topButtonGesture.reset();

      this._rightButtonGesture.reset();
    }
  }, {
    key: "handleClockTick",
    value: function handleClockTick(clockIndex) {
      this._model.clockIndex = clockIndex;

      this._view.renderClock();

      var _this$_model$notesAnd = this._model.notesAndModsForCurrentClockIndex(),
          notes = _this$_model$notesAnd.notes,
          aftertouch = _this$_model$notesAnd.aftertouch,
          modulation = _this$_model$notesAnd.modulation;

      if (notes) {
        notes.forEach(function (note) {
          return outlet(OUTLET.NOTE, note.pitch, note.velocity, note.duration);
        });
      }

      if (aftertouch != null && aftertouch !== this._prevAftertouch) {
        outlet(OUTLET.AFTERTOUCH, aftertouch);
        this._prevAftertouch = aftertouch;
      }

      if (modulation != null && modulation !== this._prevModulation) {
        // outlet(OUTLET.CC, 1, modulation);
        // TODO: Rename this to OUTLET.MOD
        outlet(OUTLET.CC, modulation);
        this._prevModulation = modulation;
      }
    }
  }, {
    key: "setDuration",
    value: function setDuration(stepDuration) {
      var store = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      // Note: The global step duration behavior is handled within the Max patch,
      // so the JavaScript code doesn't need to do anything besides render and store the current value.
      this._model.globalStepDuration = stepDuration;

      this._view.renderDuration(stepDuration);

      if (store) {
        this._storage.storeDuration(stepDuration);
      }
    }
  }, {
    key: "setScaleOffsets",
    value: function setScaleOffsets(offsets) {
      var store = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      this._model.scale.offsets = offsets;

      this._view.renderScale(this._model.scale);

      if (store) {
        this._storage.storeScaleOffsets(offsets);
      }
    }
  }, {
    key: "setScaleOffsetsRelativeToC",
    value: function setScaleOffsetsRelativeToC(offsetsRelativeToC) {
      var store = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      var root = this._model.scale.root;
      var offsets = offsetsRelativeToC.map(function (offset) {
        return (offset - root).mod(12);
      }).sort(function (a, b) {
        return a - b;
      });
      this._model.scale.offsets = offsets;

      this._view.renderScale(this._model.scale);

      if (store) {
        this._storage.storeScaleOffsets(offsets);
      }
    }
  }, {
    key: "setScaleRoot",
    value: function setScaleRoot(root) {
      var store = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      this._model.scale.root = root;

      this._view.renderScale(this._model.scale);

      if (store) {
        this._storage.storeScaleRoot(root);
      }
    }
  }, {
    key: "setModulationSummingMode",
    value: function setModulationSummingMode(mode) {
      var store = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      this._model.modulationSummingMode = mode;

      this._view.renderModulationSummingMode(mode);

      if (store) {
        this._storage.storeModulationSummingMode(mode);
      }
    }
  }, {
    key: "setModulationSlew",
    value: function setModulationSlew(slew) {
      var store = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      this._model.modulationSlew = slew;

      this._view.renderModulationSlew(slew);

      if (store) {
        this._storage.storeModulationSlew(slew);
      }
    }
  }, {
    key: "selectTrack",
    value: function selectTrack(trackIndex) {
      if (trackIndex !== this._model.selectedTrackIndex) {
        this._model.selectedTrackIndex = trackIndex;

        this._view.renderTrack(); // I'm debating renaming this to renderSelectedTrack() vs passing in a trackIndex

      }
    }
  }, {
    key: "selectPattern",
    value: function selectPattern(patternIndex) {
      var _ref = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {},
          _ref$forceRender = _ref.forceRender,
          forceRender = _ref$forceRender === void 0 ? false : _ref$forceRender;

      if (forceRender || patternIndex !== this._model.selectedPatternIndex) {
        this._model.selectedPatternIndex = patternIndex;

        this._view.renderPattern();
      }
    }
  }, {
    key: "selectOrToggleValue",
    value: function selectOrToggleValue(value) {
      this._model.selectedValue = this._model.selectedValue === value ? STEP_VALUE.OFF : value;

      this._view.renderValue();
    }
  }, {
    key: "handleGridClick",
    value: function handleGridClick(x, y, enabled) {
      this.setStepToValue(xyToIndex(x, y), enabled ? this._model.selectedValue : 0);
    }
  }, {
    key: "setStepToValue",
    value: function setStepToValue(stepIndex, value) {
      var model = this._model;
      var steps = model.selectedPattern.steps;
      steps[stepIndex] = value;

      this._view.renderStep(stepIndex);

      this._storage.storePatternStepsAfterDelay(model.selectedTrackIndex, model.selectedPatternIndex, steps);
    }
  }, {
    key: "setTrackPitch",
    value: function setTrackPitch(pitch) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var store = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      this._model.tracks[trackIndex].pitch = pitch;

      if (trackIndex === this._model.selectedTrackIndex) {
        this._view.renderTrackPitch(pitch);
      }

      if (store) {
        this._storage.storeTrackPitch(trackIndex, pitch);
      }
    }
  }, {
    key: "setTrackVelocity",
    value: function setTrackVelocity(velocity) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var store = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      this._model.tracks[trackIndex].velocity = velocity;

      if (trackIndex === this._model.selectedTrackIndex) {
        this._view.renderTrackVelocity();
      }

      if (store) {
        this._storage.storeTrackVelocity(trackIndex, velocity);
      }
    }
  }, {
    key: "setTrackGate",
    value: function setTrackGate(gate) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var store = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      this._model.tracks[trackIndex].gate = gate;

      if (trackIndex === this._model.selectedTrackIndex) {
        this._view.renderTrackGate();
      }

      if (store) {
        this._storage.storeTrackGate(trackIndex, gate);
      }
    }
  }, {
    key: "setTrackGateMode",
    value: function setTrackGateMode(mode) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var store = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      this._model.tracks[trackIndex].gateMode = mode;

      if (trackIndex === this._model.selectedTrackIndex) {
        this._view.renderTrackGateMode(mode);
      }

      if (store) {
        this._storage.storeTrackGateMode(trackIndex, mode);
      }
    }
  }, {
    key: "setTrackMultiplier",
    value: function setTrackMultiplier(multiplier) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var store = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      this._model.tracks[trackIndex].durationMultiplier = multiplier;

      if (trackIndex === this._model.selectedTrackIndex) {
        this._view.renderTrackMultiplier();
      }

      if (store) {
        this._storage.storeTrackMultiplier(trackIndex, multiplier);
      }
    }
  }, {
    key: "setTrackGateSummingMode",
    value: function setTrackGateSummingMode(mode) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var store = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      this._model.tracks[trackIndex].gateSummingMode = mode;

      if (trackIndex === this._model.selectedTrackIndex) {
        this._view.renderTrackGateSummingMode(mode);
      }

      if (store) {
        this._storage.storeTrackGateSummingMode(trackIndex, mode);
      }
    }
  }, {
    key: "setTrackMute",
    value: function setTrackMute(mute) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var store = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      this._model.tracks[trackIndex].mute = mute;

      this._view.renderTrackMute(trackIndex, mute);

      if (store) {
        this._storage.storeTrackMute(trackIndex, mute);
      }
    }
  }, {
    key: "setPatternSteps",
    value: function setPatternSteps(steps) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var patternIndex = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : this._model.selectedPatternIndex;
      var store = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
      var pattern = this._model.tracks[trackIndex].patterns[patternIndex];
      pattern.steps = steps;

      if (trackIndex === this._model.selectedTrackIndex && patternIndex === this._model.selectedPatternIndex) {
        this._view.renderGrid();
      }

      if (store) {
        this._storage.storePatternSteps(this._model.selectedTrackIndex, pattern.index, pattern.steps);
      }
    }
  }, {
    key: "setPatternStart",
    value: function setPatternStart(stepIndex) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var patternIndex = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : this._model.selectedPatternIndex;
      var store = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
      this._model.tracks[trackIndex].patterns[patternIndex].startStepIndex = stepIndex;

      if (trackIndex === this._model.selectedTrackIndex && patternIndex === this._model.selectedPatternIndex) {
        this._view.renderPatternStart();
      }

      if (store) {
        this._storage.storePatternStart(trackIndex, patternIndex, stepIndex);
      }
    }
  }, {
    key: "setPatternEnd",
    value: function setPatternEnd(stepIndex) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var patternIndex = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : this._model.selectedPatternIndex;
      var store = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
      this._model.tracks[trackIndex].patterns[patternIndex].endStepIndex = stepIndex;

      if (trackIndex === this._model.selectedTrackIndex && patternIndex === this._model.selectedPatternIndex) {
        this._view.renderPatternEnd();
      }

      if (store) {
        this._storage.storePatternEnd(trackIndex, patternIndex, stepIndex);
      }
    }
  }, {
    key: "setPatternMute",
    value: function setPatternMute(mute) {
      var trackIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._model.selectedTrackIndex;
      var patternIndex = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : this._model.selectedPatternIndex;
      var store = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : true;
      this._model.tracks[trackIndex].patterns[patternIndex].mute = mute;

      if (trackIndex === this._model.selectedTrackIndex) {
        this._view.renderPatternMute(patternIndex, mute);
      }

      if (store) {
        this._storage.storePatternMute(trackIndex, patternIndex, mute);
      }
    }
  }, {
    key: "_modifyPatternSteps",
    value: function _modifyPatternSteps(pattern, modify) {
      modify(pattern);

      this._view.renderGrid();

      this._storage.storePatternSteps(pattern.trackIndex, pattern.index, pattern.steps);
    }
  }, {
    key: "reversePattern",
    value: function reversePattern() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      this._modifyPatternSteps(pattern, function (pattern) {
        return pattern.reverse();
      });
    }
  }, {
    key: "randomizePattern",
    value: function randomizePattern() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      this._modifyPatternSteps(pattern, function (pattern) {
        return pattern.randomize();
      });
    }
  }, {
    key: "invertPattern",
    value: function invertPattern() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      this._modifyPatternSteps(pattern, function (pattern) {
        return pattern.invert();
      });
    }
  }, {
    key: "clearPattern",
    value: function clearPattern() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      this._modifyPatternSteps(pattern, function (pattern) {
        return pattern.clear();
      });
    }
  }, {
    key: "shiftPatternLeft",
    value: function shiftPatternLeft() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      this._modifyPatternSteps(pattern, function (pattern) {
        return pattern.shift(1);
      });
    }
  }, {
    key: "shiftPatternRight",
    value: function shiftPatternRight() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      this._modifyPatternSteps(pattern, function (pattern) {
        return pattern.shift(-1);
      });
    }
  }, {
    key: "shiftPatternUp",
    value: function shiftPatternUp() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      this._modifyPatternSteps(pattern, function (pattern) {
        return pattern.shift(NUMBER_OF.COLUMNS);
      });
    }
  }, {
    key: "shiftPatternDown",
    value: function shiftPatternDown() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      this._modifyPatternSteps(pattern, function (pattern) {
        return pattern.shift(-NUMBER_OF.COLUMNS);
      });
    }
  }, {
    key: "copyPatternSteps",
    value: function copyPatternSteps() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;
      this._patternStepsClipboard = pattern.steps.slice(); // slice to freeze this state
    }
  }, {
    key: "pastePatternSteps",
    value: function pastePatternSteps() {
      var _this = this;

      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      if (this._patternStepsClipboard) {
        this._modifyPatternSteps(pattern, function (pattern) {
          return pattern.steps = _this._patternStepsClipboard.slice();
        } // slice to prevent a shared steps array between patterns
        );
      }
    }
  }, {
    key: "_recordPatternStepsForUndo",
    value: function _recordPatternStepsForUndo() {
      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;
      this._patternStepsUndo = pattern.steps.slice(); // slice to freeze this state
    }
  }, {
    key: "_undoPatternStepsChange",
    value: function _undoPatternStepsChange() {
      var _this2 = this;

      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;

      if (this._patternStepsUndo) {
        this._modifyPatternSteps(pattern, function (pattern) {
          return pattern.steps = _this2._patternStepsUndo;
        });

        this._patternStepsUndo = null;
      }
    }
  }, {
    key: "reverseTrack",
    value: function reverseTrack() {
      var _this3 = this;

      var track = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedTrack;
      track.patterns.forEach(function (pattern) {
        return _this3.reversePattern(pattern);
      });
    }
  }, {
    key: "randomizeTrack",
    value: function randomizeTrack() {
      var _this4 = this;

      var track = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedTrack;
      track.patterns.forEach(function (pattern) {
        return _this4.randomizePattern(pattern);
      });
    }
  }, {
    key: "clearTrack",
    value: function clearTrack() {
      var _this5 = this;

      var track = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedTrack;
      track.patterns.forEach(function (pattern) {
        return _this5.clearPattern(pattern);
      });
    }
  }, {
    key: "copyTrackSteps",
    value: function copyTrackSteps() {
      var track = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedTrack;
      this._trackStepsClipboard = track.patterns.map(function (pattern) {
        return pattern.steps.slice();
      }); // slice to freeze this state
    }
  }, {
    key: "pasteTrackSteps",
    value: function pasteTrackSteps() {
      var _this6 = this;

      var track = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedTrack;

      if (this._trackStepsClipboard) {
        this._trackStepsClipboard.forEach(function (patternSteps, patternIndex) {
          return _this6._modifyPatternSteps(track.patterns[patternIndex], function (pattern) {
            return pattern.steps = patternSteps.slice();
          } // slice to prevent a shared steps array between patterns
          );
        });
      }
    }
  }]);

  return Controller;
}();

var Scale = /*#__PURE__*/function () {
  function Scale() {
    var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        _ref$root = _ref.root,
        root = _ref$root === void 0 ? DEFAULT.SCALE_ROOT : _ref$root,
        _ref$offsets = _ref.offsets,
        offsets = _ref$offsets === void 0 ? DEFAULT.SCALE_OFFSETS : _ref$offsets;

    _classCallCheck(this, Scale);

    this.root = root;
    this.offsets = offsets;
  }

  _createClass(Scale, [{
    key: "reset",
    value: function reset() {
      this.root = DEFAULT.SCALE_ROOT;
      this.offsets = DEFAULT.SCALE_OFFSETS;
    }
  }, {
    key: "toggle",
    value: function toggle(pitch, enabled) {
      if (enabled) {
        if (this._didSetOffsetsSinceLastToggle) {
          this._offsets = []; // override what was set in the GUI

          this._didSetOffsetsSinceLastToggle = false;
        }

        if (!this._offsets.length) {
          this.root = pitch.mod(12);
        }

        this._offsets.push(pitch - 60 - this.root); // relative to middle octave

      } else {
        var offset = pitch - 60 - this.root;

        var index = this._offsets.indexOf(offset);

        if (index >= 0) {
          this._offsets.splice(index, 1);
        }
      }
    }
  }, {
    key: "pitchAt",
    value: function pitchAt(octave, interval) {
      var length = this._offsets.length;

      if (length) {
        return this._offsets[interval.mod(length)] + 12 * (octave + Math.floor(interval / length));
      }
    }
  }, {
    key: "offsets",
    get: function get() {
      return this._offsets;
    },
    set: function set(offsets) {
      this._offsets = offsets.slice();
      this._didSetOffsetsSinceLastToggle = true; // this indicates the GUI changed the offsets
    }
  }]);

  return Scale;
}();

var Note = /*#__PURE__*/function () {
  function Note() {
    _classCallCheck(this, Note);

    this.reset();
  }

  _createClass(Note, [{
    key: "reset",
    value: function reset() {
      this.pitch = 0;
      this.velocity = 0;
      this.duration = 1;
      this.mute = false;
      this.enabled = false;
      this.gateValue = 0; // Modulation and aftertouch aren't relly part of a "note"
      // but it's makes this a convenient model for evaluating a sequencer step:

      this.modulation = 0;
      this.aftertouch = 0;
    }
  }]);

  return Note;
}();

//
// It consists of 64 steps with integer values (typically 0-4 for off,green,yellow,orange,red lights),
// a start step, and an end step.
//

var Pattern = /*#__PURE__*/function () {
  function Pattern() {
    var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
        trackIndex = _ref.trackIndex,
        index = _ref.index,
        type = _ref.type;

    _classCallCheck(this, Pattern);

    this.trackIndex = trackIndex;
    this.index = index;
    this.type = type;
    this.reset();
  }

  _createClass(Pattern, [{
    key: "reset",
    value: function reset() {
      this._steps = Array(NUMBER_OF.STEPS).fill(0);
      this.startStepIndex = 0;
      this.endStepIndex = NUMBER_OF.STEPS - 1;
      this.mute = false;
    }
  }, {
    key: "setRange",
    value: function setRange(index1, index2) {
      this.startStepIndex = Math.min(index1, index2);
      this.endStepIndex = Math.max(index1, index2);
    }
  }, {
    key: "clear",
    value: function clear() {
      this._steps = Array(NUMBER_OF.STEPS).fill(0);
    }
  }, {
    key: "randomize",
    value: function randomize() {
      var steps = this.steps,
          start = this.startStepIndex,
          end = this.endStepIndex;

      for (var i = start; i <= end; i++) {
        steps[i] = Math.floor(NUMBER_OF.STEP_VALUES * Math.random());
      }
    } // fill in value with 25% chance

  }, {
    key: "randomFill",
    value: function randomFill(value) {
      var steps = this.steps,
          start = this.startStepIndex,
          end = this.endStepIndex;

      for (var i = start; i <= end; i++) {
        if (Math.random() < 0.25) {
          steps[i] = value;
        }
      }
    }
  }, {
    key: "fill",
    value: function fill(value) {
      var steps = this.steps,
          start = this.startStepIndex,
          end = this.endStepIndex;

      for (var i = start; i <= end; i++) {
        steps[i] = value;
      }
    }
  }, {
    key: "replace",
    value: function replace(value) {
      var steps = this.steps,
          start = this.startStepIndex,
          end = this.endStepIndex;

      for (var i = start; i <= end; i++) {
        if (steps[i] > 0) {
          steps[i] = value;
        }
      }
    }
  }, {
    key: "reverse",
    value: function reverse() {
      var steps = this.steps,
          start = this.startStepIndex,
          end = this.endStepIndex;
      var before = steps.slice(0, start);
      var activeSteps = steps.slice(start, end + 1);
      var after = steps.slice(end + 1);
      this.steps = before.concat(activeSteps.reverse(), after);
    } // Flips value 1 with 4, and 2 with 3

  }, {
    key: "invert",
    value: function invert() {
      var steps = this.steps,
          start = this.startStepIndex,
          end = this.endStepIndex;

      for (var i = start; i <= end; i++) {
        var value = steps[i];

        if (value > 0) {
          steps[i] = NUMBER_OF.STEP_VALUES - value;
        }
      }
    }
  }, {
    key: "shift",
    value: function shift(amount) {
      var steps = this.steps,
          start = this.startStepIndex,
          end = this.endStepIndex,
          length = this.length;
      var rot = start + amount.mod(length);
      var before = steps.slice(0, start);
      var left = steps.slice(start, rot);
      var right = steps.slice(rot, end + 1);
      var after = steps.slice(end + 1);
      this.steps = before.concat(right, left, after);
    }
  }, {
    key: "processNote",
    value: function processNote(note, clock) {
      if (this.mute) return;
      var stepIndex = this.startStepIndex + clock.mod(this.length);
      var value = this.steps[stepIndex];

      if (value > 0) {
        // Assumption: 0 is always a NOOP
        switch (this.type) {
          case 'velocity':
            note.velocity += (127 - note.velocity) * value / 4;
            break;

          case 'duration':
            note.duration = STEP_VALUE.DURATION[value];
            break;

          case 'aftertouch':
            note.aftertouch = 127 * value / 4;
            break;

          case 'modulation':
            note.modulation = 127 * value / 4;
            break;

          case 'random mute':
            if (Math.random() <= value / 4) {
              note.mute = true;
            }

            break;

          case 'gate':
            note.gateValue = value;
            break;

          default:
            console.log("ERROR in processNote(). Unexpected type \"".concat(this.type, "\""));
        }
      }
    }
  }, {
    key: "steps",
    get: function get() {
      return this._steps;
    },
    set: function set(steps) {
      // ensure this._steps remains valid
      for (var i = 0; i < NUMBER_OF.STEPS; i++) {
        this._steps[i] = steps[i] || 0;
      }
    }
  }, {
    key: "range",
    get: function get() {
      return [this.startStepIndex, this.endStepIndex];
    }
  }, {
    key: "length",
    get: function get() {
      return this.endStepIndex - this.startStepIndex + 1;
    }
  }]);

  return Pattern;
}();

var GATE$2 = MODE.GATE,
    GATE_SUMMING = MODE.GATE_SUMMING;

var randomItem = function randomItem(list) {
  return list[Math.floor(Math.random() * list.length)];
};

var Track = /*#__PURE__*/function () {
  function Track(index) {
    _classCallCheck(this, Track);

    this.index = index;
    this.patterns = _toConsumableArray(Array(NUMBER_OF.PATTERNS)).map(function (_, patternIndex) {
      return new Pattern({
        trackIndex: index,
        index: patternIndex,
        type: DEFAULT.PATTERN_TYPES[patternIndex]
      });
    });
    this.reset();
  }

  _createClass(Track, [{
    key: "reset",
    value: function reset() {
      this.pitch = DEFAULT.PITCH;
      this.velocity = DEFAULT.VELOCITY;
      this.gate = DEFAULT.GATE;
      this.gateMode = DEFAULT.GATE_MODE;
      this.gateSummingMode = DEFAULT.GATE_SUMMING_MODE;
      this.patterns.forEach(function (pattern) {
        return pattern.reset();
      });
      this.durationMultiplier = 1;
      this.mute = false;
      this._notes = [new Note(), new Note(), new Note()]; // multi sum mode can output up to 3 notes
    }
  }, {
    key: "notesForClock",
    value: function notesForClock(clock, scale) {
      var _this$_notes = _slicedToArray(this._notes, 3),
          note = _this$_notes[0],
          note2 = _this$_notes[1],
          note3 = _this$_notes[2]; // avoid creating and garbage collecting objects each clock tick


      if (this.mute || clock < 0 || clock % this.durationMultiplier !== 0) {
        // return the previous note to maintain the modulation and aftertouch value when we're in between track steps
        note.enabled = false;
        return [note]; // TODO: Can we avoid constructing an array here?
      }

      var trackClock = clock / this.durationMultiplier;

      this._notes.forEach(function (note) {
        return note.reset();
      });

      note.pitch = this._pitch;
      note.velocity = this.velocity;
      this.patterns.forEach(function (pattern, index) {
        switch (index) {
          case PATTERN.GATE2:
            pattern.processNote(note2, trackClock, scale);
            break;

          case PATTERN.GATE3:
            pattern.processNote(note3, trackClock, scale);
            break;

          default:
            pattern.processNote(note, trackClock, scale);
        }
      });

      var gateValue = this._gateValue();

      if (gateValue > 0 && !note.mute) {
        note.enabled = true;
        note.duration *= this.gate * this.durationMultiplier; // track.gate and durationMultiplier scales the note's duration

        var velocity = note.velocity;
        var duration = note.duration;

        switch (this.gateMode) {
          case GATE$2.PITCH:
            var octave = this._octave;
            var offset = this._offset;

            if (this.gateSummingMode === GATE_SUMMING.MULTI) {
              if (note.gateValue > 0) {
                // the first gate value maps to the track pitch, so subtract 1 and apply the scale
                note.pitch = scale.pitchAt(octave, offset + (note.gateValue - 1));
              } else {
                note.enabled = false;
              }

              if (note2.gateValue > 0) {
                note2.enabled = true;
                note2.pitch = scale.pitchAt(octave, offset + (note2.gateValue - 1));
                note2.velocity = velocity;
                note2.duration = duration;
              }

              if (note3.gateValue > 0) {
                note3.enabled = true;
                note3.pitch = scale.pitchAt(octave, offset + (note3.gateValue - 1));
                note3.velocity = velocity;
                note3.duration = duration;
              }
            } else {
              // AVERAGE mode can result in fractional values so we round() first to ensure we end up with a scale pitch
              note.pitch = scale.pitchAt(octave, offset + Math.round(gateValue) - 1);
            }

            break;

          case GATE$2.VELOCITY:
            var deltaToMax = 127 - velocity;

            if (this.gateSummingMode === GATE_SUMMING.MULTI) {
              var pitch = note.pitch;

              if (note.gateValue > 0) {
                // Pitches are not constrained to scale in for velocity gates.
                // Start with the highest pitch and go down to the track pitch on the last pattern.
                note.pitch = pitch + 2;
                note.velocity = velocity + deltaToMax * (note.gateValue - 1) / 3;
              } else {
                note.enabled = false;
              }

              if (note2.gateValue > 0) {
                note2.enabled = true;
                note2.pitch = pitch + 1;
                note2.velocity = velocity + deltaToMax * (note2.gateValue - 1) / 3;
                note2.duration = duration;
              }

              if (note3.gateValue > 0) {
                note3.enabled = true;
                note3.pitch = pitch;
                note3.velocity = velocity + deltaToMax * (note3.gateValue - 1) / 3;
                note3.duration = duration;
              }
            } else {
              // With ADD mode, the velocity can exceed 127
              note.velocity = Math.min(127, velocity + deltaToMax * (gateValue - 1) / 3);
            }

            break;

          default:
            console.log("ERROR in notesForClock(). Unexpected gate mode \"".concat(this.gateMode, "\""));
        }
      }

      return this._notes;
    }
  }, {
    key: "patternStepIndexForClock",
    value: function patternStepIndexForClock(clock, patternIndex) {
      if (clock < 0) return -1;
      var trackClock = Math.floor(clock / this.durationMultiplier);
      var pattern = this.patterns[patternIndex];
      return pattern.startStepIndex + trackClock.mod(pattern.length);
    }
  }, {
    key: "_gateValue",
    value: function _gateValue() {
      var values = this._notes.map(function (n) {
        return n.gateValue;
      });

      switch (this.gateSummingMode) {
        case GATE_SUMMING.ADD:
          return values.reduce(function (a, b) {
            return a + b;
          });

        case GATE_SUMMING.AVERAGE:
          var average = values.reduce(function (a, b) {
            return a + b;
          }) / values.length; // The minimum value for a gate needs to be 1 so we don't go below the track's pitch/velocity
          // See the `- 1` logic in notesForClock().

          return average > 0 && average < 1 ? 1 : average;

        case GATE_SUMMING.HIGHEST:
          return Math.max.apply(Math, _toConsumableArray(values));

        case GATE_SUMMING.LOWEST:
          var nonZeros = values.filter(function (v) {
            return v > 0;
          });
          return nonZeros.length ? Math.min.apply(Math, _toConsumableArray(nonZeros)) : 0;

        case GATE_SUMMING.MULTI:
          // notesForClock() handles the multi-note behavior.
          // We only need to attempt to process this step if there's a non-zero value:
          return values.reduce(function (a, b) {
            return a + b;
          });

        case GATE_SUMMING.RANDOM:
          return randomItem(values.filter(function (v) {
            return v > 0;
          })) || 0;

        case GATE_SUMMING.RANDOM_WITH_0:
          return randomItem(values);

        default:
          console.error("Error in _gateValue(). Unexpected gate summing mode \"".concat(this.gateSummingMode, "\""));
          return 0;
      }
    }
  }, {
    key: "pitch",
    get: function get() {
      return this._pitch;
    },
    set: function set(pitch) {
      this._pitch = pitch;
      this._octave = Math.floor(pitch / 12);
      this._offset = pitch % 12;
    }
  }]);

  return Track;
}();

var GATE_SUMMING$1 = MODE.GATE_SUMMING;

var Model = /*#__PURE__*/function () {
  function Model() {
    _classCallCheck(this, Model);

    this.scale = new Scale();
    this.tracks = _toConsumableArray(Array(NUMBER_OF.TRACKS)).map(function (_, index) {
      return new Track(index);
    });
    this.reset();
  }

  _createClass(Model, [{
    key: "reset",
    value: function reset() {
      this.globalStepDuration = DEFAULT.STEP_DURATION; // behavior handled by Max, only for storage and rendering

      this.scale.reset();
      this.modulationSummingMode = DEFAULT.MODULATION_SUMMING_MODE;
      this.modulationSlew = DEFAULT.MODULATION_SLEW; // behavior handled by Max, only for storage and rendering

      this.tracks.forEach(function (track) {
        return track.reset();
      });
      this.selectedTrackIndex = 0;
      this.selectedPatternIndex = NUMBER_OF.PATTERNS - 1; // The last pattern is a note-producing pattern (and the first is not)

      this.selectedValue = DEFAULT.VALUE;
      this.clockIndex = -1;
      this.mode = MODE.SEQUENCER;
      this._aftertouchValues = [];
      this._modulationValues = [];
    }
  }, {
    key: "notesAndModsForCurrentClockIndex",
    value: function notesAndModsForCurrentClockIndex() {
      var _this = this;

      var clockIndex = this.clockIndex;

      if (clockIndex < 0) {
        return {};
      }

      var atValues = this._aftertouchValues;
      var modValues = this._modulationValues;
      var hasPitch = {};
      var dedupedNotes = [];
      this.tracks.forEach(function (track, trackIndex) {
        var notes = track.notesForClock(_this.clockIndex, _this.scale);
        notes.forEach(function (note) {
          if (note && note.enabled) {
            if (note.pitch != null && !hasPitch[note.pitch]) {
              dedupedNotes.push(note);
              hasPitch[note.pitch] = true;
            }
          }
        }); // We only use the first note to store aftertouch and modulation:
        // (TODO: track.notesForClock() could return dedicated aftertouch and modulation values like below)

        atValues[trackIndex] = track.mute ? 0 : notes[0].aftertouch;
        modValues[trackIndex] = track.mute ? 0 : notes[0].modulation;
      });
      return {
        notes: dedupedNotes,
        aftertouch: this._modValue(atValues),
        modulation: this._modValue(modValues)
      };
    }
  }, {
    key: "_modValue",
    value: function _modValue(values) {
      switch (this.modulationSummingMode) {
        case GATE_SUMMING$1.ADD:
          return values.reduce(function (x, y) {
            return x + y;
          });

        case GATE_SUMMING$1.AVERAGE:
          return values.reduce(function (x, y) {
            return x + y;
          }) / values.length;

        case GATE_SUMMING$1.HIGHEST:
          return Math.max.apply(Math, _toConsumableArray(values));

        case GATE_SUMMING$1.LOWEST:
          return Math.min.apply(Math, _toConsumableArray(values));

        case GATE_SUMMING$1.RANDOM:
          return values[Math.floor(Math.random() * values.length)];

        default:
          console.error("Error in _modValue(). Unexpected modulation summing mode \"".concat(this.modulationSummingMode, "\""));
          return 0;
      }
    }
  }, {
    key: "selectedTrack",
    get: function get() {
      return this.tracks[this.selectedTrackIndex];
    }
  }, {
    key: "selectedPattern",
    get: function get() {
      return this.selectedTrack.patterns[this.selectedPatternIndex];
    }
  }]);

  return Model;
}();

var STEP_WIDTH = GUI.STEP_WIDTH,
    BUTTON_WIDTH = GUI.BUTTON_WIDTH; // These need to match the [route] objects connected to the GUI outlet in the Max patch.
// TODO: Is there a reason these don't reuse the storage constants?

var GRID = 'grid';
var DURATION$2 = 'duration';
var SCALE_OFFSETS$2 = 'scale';
var SCALE_ROOT$2 = 'root';
var MODULATION_SLEW$2 = 'modslew';
var MODULATION_SUMMING_MODE$2 = 'modsum';
var TRACK = 'track';
var PATTERN$1 = 'pattern';
var VALUE = 'value';
var INDEX = 'index';
var PITCH$2 = 'pitch';
var VELOCITY$2 = 'velocity';
var GATE$3 = 'gate';
var GATE_MODE$2 = 'gatemode';
var GATE_SUMMING_MODE$2 = 'gatesum';
var MULTIPLIER$2 = 'multiplier';
var MUTE$2 = 'mute';
var INDEX_MUTE = 'index-mute';
var START$2 = 'start';
var END$2 = 'end';

var GuiView = /*#__PURE__*/function () {
  function GuiView(model) {
    _classCallCheck(this, GuiView);

    this._model = model;
    this._oldlines = [];
  }

  _createClass(GuiView, [{
    key: "render",
    value: function render() {
      var _this = this;

      this.renderDuration(this._model.globalStepDuration);
      this.renderScale(this._model.scale);
      this.renderModulationSummingMode(this._model.modulationSummingMode);
      this.renderModulationSlew(this._model.modulationSlew);
      this.renderTrack(this._model.selectedTrack);
      this.renderValueButton(this._model.selectedValue);
      this.renderPattern(this._model.selectedPattern);
      this.renderGrid();

      this._model.tracks.forEach(function (track) {
        return _this.renderTrackSelectorMute(track.index, track.mute);
      });
    }
  }, {
    key: "clearGrid",
    value: function clearGrid() {
      outlet(OUTLET.GRID, 'clear');
    }
  }, {
    key: "renderDuration",
    value: function renderDuration(duration) {
      outlet(OUTLET.GUI, DURATION$2, duration);
    }
  }, {
    key: "renderScale",
    value: function renderScale(scale) {
      var root = scale.root;
      var offsetsRelativeToC = scale.offsets.map(function (offset) {
        return (root + offset).mod(12);
      });
      outlet(OUTLET.GUI, SCALE_ROOT$2, root);
      outlet(OUTLET.GUI, SCALE_OFFSETS$2, offsetsRelativeToC);
    }
  }, {
    key: "renderModulationSummingMode",
    value: function renderModulationSummingMode(mode) {
      outlet(OUTLET.GUI, MODULATION_SUMMING_MODE$2, mode);
    }
  }, {
    key: "renderModulationSlew",
    value: function renderModulationSlew(slew) {
      outlet(OUTLET.GUI, MODULATION_SLEW$2, slew);
    }
  }, {
    key: "renderTrack",
    value: function renderTrack(track) {
      var _this2 = this;

      this.renderTrackIndex(track.index);
      this.renderTrackPitch(track.pitch);
      this.renderTrackVelocity(track.velocity);
      this.renderTrackGate(track.gate);
      this.renderTrackGateMode(track.gateMode);
      this.renderTrackGateSummingMode(track.gateSummingMode);
      this.renderTrackMultiplier(track.durationMultiplier);
      this.renderTrackMute(track.mute);

      this._model.selectedTrack.patterns.forEach(function (pattern) {
        return _this2.renderPatternSelectorMute(pattern.index, pattern.mute);
      });
    }
  }, {
    key: "renderTrackIndex",
    value: function renderTrackIndex(index) {
      outlet(OUTLET.GUI, TRACK, INDEX, index);
    }
  }, {
    key: "renderTrackPitch",
    value: function renderTrackPitch(pitch) {
      outlet(OUTLET.GUI, TRACK, PITCH$2, pitch);
    }
  }, {
    key: "renderTrackVelocity",
    value: function renderTrackVelocity(velocity) {
      outlet(OUTLET.GUI, TRACK, VELOCITY$2, velocity);
    }
  }, {
    key: "renderTrackGate",
    value: function renderTrackGate(gate) {
      outlet(OUTLET.GUI, TRACK, GATE$3, gate);
    }
  }, {
    key: "renderTrackGateMode",
    value: function renderTrackGateMode(mode) {
      outlet(OUTLET.GUI, TRACK, GATE_MODE$2, mode);
    }
  }, {
    key: "renderTrackGateSummingMode",
    value: function renderTrackGateSummingMode(mode) {
      outlet(OUTLET.GUI, TRACK, GATE_SUMMING_MODE$2, mode);
    }
  }, {
    key: "renderTrackMultiplier",
    value: function renderTrackMultiplier(multiplier) {
      outlet(OUTLET.GUI, TRACK, MULTIPLIER$2, multiplier);
    }
  }, {
    key: "renderTrackMute",
    value: function renderTrackMute(mute) {
      outlet(OUTLET.GUI, TRACK, MUTE$2, mute);
    }
  }, {
    key: "renderTrackSelectorMute",
    value: function renderTrackSelectorMute(trackIndex, mute) {
      outlet(OUTLET.GUI, TRACK, INDEX_MUTE, trackIndex, mute);
    }
  }, {
    key: "renderValueButton",
    value: function renderValueButton(value) {
      outlet(OUTLET.GUI, VALUE, value);
    }
  }, {
    key: "renderPattern",
    value: function renderPattern(pattern) {
      this.renderPatternIndex(pattern.index);
      this.renderPatternStart(pattern.startStepIndex, false);
      this.renderPatternEnd(pattern.endStepIndex, false);
      this.renderPatternMute(pattern.mute);
      this.renderGrid(pattern);
    }
  }, {
    key: "renderPatternIndex",
    value: function renderPatternIndex(index) {
      outlet(OUTLET.GUI, PATTERN$1, INDEX, index);
    }
  }, {
    key: "renderPatternStart",
    value: function renderPatternStart(start) {
      var renderGrid = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      outlet(OUTLET.GUI, PATTERN$1, START$2, start + 1);
      if (renderGrid) this.renderGrid();
    }
  }, {
    key: "renderPatternEnd",
    value: function renderPatternEnd(end) {
      var renderGrid = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
      outlet(OUTLET.GUI, PATTERN$1, END$2, end + 1);
      if (renderGrid) this.renderGrid();
    }
  }, {
    key: "renderPatternMute",
    value: function renderPatternMute(mute) {
      outlet(OUTLET.GUI, PATTERN$1, MUTE$2, mute);
    }
  }, {
    key: "renderPatternSelectorMute",
    value: function renderPatternSelectorMute(patternIndex, mute) {
      outlet(OUTLET.GUI, PATTERN$1, INDEX_MUTE, patternIndex, mute);
    }
  }, {
    key: "renderGrid",
    value: function renderGrid() {
      var _this3 = this;

      var pattern = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedPattern;
      var start = pattern.startStepIndex,
          end = pattern.endStepIndex; // Draw start end/step indicators:

      var delta = BUTTON_WIDTH + 3;
      var startX = start % 8 * STEP_WIDTH;
      var startY = Math.floor(start / 8) * STEP_WIDTH;
      var endX = end % 8 * STEP_WIDTH;
      var endY = Math.floor(end / 8) * STEP_WIDTH;
      var lines = [[startX + delta, startY, startX, startY], [startX, startY, startX, startY + delta], [startX, startY + delta, startX + delta, startY + delta], [endX, endY, endX + delta, endY], [endX + delta, endY, endX + delta, endY + delta], [endX + delta, endY + delta, endX, endY + delta]]; // draw the old lines with the background color to erase them:

      this.setColor(GUI_COLOR.BACKGROUND);

      this._oldlines.forEach(function (oldLine) {
        return _this3.drawline(oldLine);
      });

      this.setColor(GUI_COLOR.PATTERN_START_END);
      lines.forEach(function (line) {
        return _this3.drawline(line);
      });
      this._oldlines = lines;
      var sequencerStepIndex = this._stepIndexForClock;
      pattern.steps.forEach(function (_, stepIndex) {
        return _this3.renderStep(stepIndex, sequencerStepIndex);
      });
    }
  }, {
    key: "renderStep",
    value: function renderStep(stepIndex) {
      var sequencerStepIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._stepIndexForClock;
      var x = stepIndex % NUMBER_OF.COLUMNS;
      var y = Math.floor(stepIndex / NUMBER_OF.COLUMNS);
      var value = this._model.selectedPattern.steps[stepIndex];
      var color = stepIndex === sequencerStepIndex ? GUI_COLOR.SEQUENCER_STEP : GUI_COLOR.STEP_VALUE[value];
      var left = x * STEP_WIDTH + 2;
      var top = y * STEP_WIDTH + 2;
      this.setColor(color);
      outlet(OUTLET.GUI, GRID, 'paintrect', left, top, left + BUTTON_WIDTH, top + BUTTON_WIDTH);
    }
  }, {
    key: "setColor",
    value: function setColor(color) {
      outlet(OUTLET.GUI, GRID, 'frgb', color);
    }
  }, {
    key: "drawline",
    value: function drawline(line) {
      outlet(OUTLET.GUI, GRID, 'linesegment', line);
    }
  }, {
    key: "_stepIndexForClock",
    get: function get() {
      var _this$_model = this._model,
          clockIndex = _this$_model.clockIndex,
          selectedTrack = _this$_model.selectedTrack,
          selectedPatternIndex = _this$_model.selectedPatternIndex;
      return clockIndex < 0 ? -1 : selectedTrack.patternStepIndexForClock(clockIndex, selectedPatternIndex);
    }
  }]);

  return GuiView;
}();

var LaunchpadView = /*#__PURE__*/function () {
  function LaunchpadView(model) {
    _classCallCheck(this, LaunchpadView);

    this._model = model;
  }

  _createClass(LaunchpadView, [{
    key: "clear",
    value: function clear() {
      outlet(OUTLET.LAUNCHPAD_CC, 0, 0);
    }
  }, {
    key: "renderTrackButton",
    value: function renderTrackButton(trackIndex) {
      this._setTopButtonColor(trackIndex, this._colorForTrackButton(trackIndex));
    }
  }, {
    key: "renderValueButton",
    value: function renderValueButton(value) {
      if (value > 0) {
        this._setTopButtonColor(value + 3, this._colorForValueButton(value));
      }
    }
  }, {
    key: "renderPatternButton",
    value: function renderPatternButton(patternIndex) {
      this._setRightButtonColor(patternIndex, this._colorForPatternButton(patternIndex));
    }
  }, {
    key: "renderStepButton",
    value: function renderStepButton(stepIndex) {
      this._setGridColor(stepIndex, this._colorForGridButton(stepIndex));
    }
  }, {
    key: "render",
    value: function render() {
      var _this = this;

      var model = this._model; // Color order: grid from left-to-right/top-to-bottom, right column (patterns) top-to-bottom, top row left-to-right

      var colors = [].concat(_toConsumableArray(this._colorsForGridButtons()), _toConsumableArray(model.selectedTrack.patterns.map(function (_, patternIndex) {
        return _this._colorForPatternButton(patternIndex);
      })));

      if (model.mode === MODE.PATTERN_EDIT) {
        colors.push(LAUNCHPAD_COLOR.YELLOW, LAUNCHPAD_COLOR.YELLOW, LAUNCHPAD_COLOR.YELLOW, LAUNCHPAD_COLOR.YELLOW, // Next 2 are for reverse and invert
        LAUNCHPAD_COLOR.YELLOW, LAUNCHPAD_COLOR.YELLOW, // Last 2 are copy & paste
        LAUNCHPAD_COLOR.GREEN, LAUNCHPAD_COLOR.RED);
      } else {
        model.tracks.forEach(function (_, trackIndex) {
          colors.push(_this._colorForTrackButton(trackIndex));
        });

        for (var value = 1; value < 5; value++) {
          colors.push(this._colorForValueButton(value));
        }
      }

      if (colors.length !== 80) {
        console.error("Error in LaunchpadView.render(): Expected colors.length to be 80, but was ".concat(colors.length, "."), colors);
        return;
      }

      outlet(OUTLET.LAUNCHPAD_RAPID_UPDATE, colors);
    } //--------------------------------------------------------
    // Private methods

  }, {
    key: "_setTopButtonColor",
    value: function _setTopButtonColor(index, color) {
      if (0 <= index && index <= 7) {
        outlet(OUTLET.LAUNCHPAD_CC, LAUNCHPAD.TOP_ROW_CC + index, color);
      }
    }
  }, {
    key: "_setRightButtonColor",
    value: function _setRightButtonColor(index, color) {
      if (0 <= index && index <= 7) {
        outlet(OUTLET.LAUNCHPAD_NOTE, 16 * index + 8, color);
      }
    }
  }, {
    key: "_setGridColor",
    value: function _setGridColor(stepIndex, color) {
      var x = stepIndex % NUMBER_OF.COLUMNS;
      var y = Math.floor(stepIndex / NUMBER_OF.COLUMNS);

      if (0 <= x && x <= 7 && 0 <= y && y <= 7) {
        outlet(OUTLET.LAUNCHPAD_NOTE, 16 * y + x, color);
      }
    }
  }, {
    key: "_colorForTrackButton",
    value: function _colorForTrackButton(trackIndex) {
      var model = this._model;
      var mute = model.tracks[trackIndex].mute;
      var selected = trackIndex === model.selectedTrackIndex;

      if (mute) {
        return selected ? LAUNCHPAD_COLOR.MUTE_COLOR : LAUNCHPAD_COLOR.INACTIVE_MUTE_COLOR;
      } else {
        return selected ? LAUNCHPAD_COLOR.TRACK_COLOR : LAUNCHPAD_COLOR.OFF;
      }
    }
  }, {
    key: "_colorForValueButton",
    value: function _colorForValueButton(value) {
      return this._model.selectedValue === value ? LAUNCHPAD_COLOR.STEP_VALUES[value] : LAUNCHPAD_COLOR.OFF;
    }
  }, {
    key: "_colorForPatternButton",
    value: function _colorForPatternButton(patternIndex) {
      var model = this._model;
      var mute = model.selectedTrack.patterns[patternIndex].mute;
      var selected = patternIndex === model.selectedPatternIndex;

      if (mute) {
        return selected ? LAUNCHPAD_COLOR.MUTE_COLOR : LAUNCHPAD_COLOR.INACTIVE_MUTE_COLOR;
      } else {
        return selected ? LAUNCHPAD_COLOR.PATTERN_COLOR : LAUNCHPAD_COLOR.OFF;
      }
    }
  }, {
    key: "_colorForGridButton",
    value: function _colorForGridButton(stepIndex) {
      var sequencerStepIndex = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this._stepIndexForClock;
      var model = this._model;
      var selectedPattern = model.selectedPattern;
      var value = selectedPattern.steps[stepIndex];
      var startStepIndex = selectedPattern.startStepIndex,
          endStepIndex = selectedPattern.endStepIndex;

      switch (model.mode) {
        case MODE.SEQUENCER:
          if (stepIndex === sequencerStepIndex) {
            return LAUNCHPAD_COLOR.SEQUENCER_STEP;
          }

          return startStepIndex <= stepIndex && stepIndex <= endStepIndex ? LAUNCHPAD_COLOR.STEP_VALUES[value] : LAUNCHPAD_COLOR.INACTIVE_STEPS[value];

        case MODE.PATTERN_EDIT:
          if (startStepIndex <= stepIndex && stepIndex <= endStepIndex) {
            return LAUNCHPAD_COLOR.STEP_VALUES[value];
          }

          return LAUNCHPAD_COLOR.OFF;

        default:
          console.log("ERROR in _colorForGridButton(). Unexpected mode \"".concat(model.mode, "\""));
      }
    }
  }, {
    key: "_colorsForGridButtons",
    value: function _colorsForGridButtons() {
      var _this2 = this;

      var sequencerStepIndex = this._stepIndexForClock;
      return this._model.selectedPattern.steps.map(function (_, stepIndex) {
        return _this2._colorForGridButton(stepIndex, sequencerStepIndex);
      });
    }
  }, {
    key: "_stepIndexForClock",
    // TODO: this is duplciated in GuiView. Can we refactor?
    get: function get() {
      var _this$_model = this._model,
          clockIndex = _this$_model.clockIndex,
          selectedTrack = _this$_model.selectedTrack,
          selectedPatternIndex = _this$_model.selectedPatternIndex;
      return clockIndex < 0 ? -1 : selectedTrack.patternStepIndexForClock(clockIndex, selectedPatternIndex);
    }
  }]);

  return LaunchpadView;
}();

var View = /*#__PURE__*/function () {
  function View(model) {
    _classCallCheck(this, View);

    this._model = model;
    this._guiView = new GuiView(model);
    this._launchpadView = new LaunchpadView(model);
    this._selectedValue = null;
    this._clockIndex = -1;
  }

  _createClass(View, [{
    key: "render",
    value: function render() {
      this._guiView.render();

      this._launchpadView.render();
    }
  }, {
    key: "renderTrack",
    value: function renderTrack() {
      this._launchpadView.render();

      this._guiView.renderTrack(this._model.selectedTrack);

      this._guiView.renderPattern(this._model.selectedPattern);

      this._guiView.renderGrid();
    }
  }, {
    key: "renderDuration",
    value: function renderDuration(duration) {
      this._guiView.renderDuration(duration);
    }
  }, {
    key: "renderScale",
    value: function renderScale(scale) {
      this._guiView.renderScale(scale);
    }
  }, {
    key: "renderModulationSummingMode",
    value: function renderModulationSummingMode(mode) {
      this._guiView.renderModulationSummingMode(mode);
    }
  }, {
    key: "renderModulationSlew",
    value: function renderModulationSlew(slew) {
      this._guiView.renderModulationSlew(slew);
    }
  }, {
    key: "renderTrackIndex",
    value: function renderTrackIndex() {
      this._guiView.renderTrackIndex(this._model.selectedTrackIndex);

      this._launchpadView.renderTrackButton(this._model.selectedTrackIndex);
    }
  }, {
    key: "renderTrackPitch",
    value: function renderTrackPitch() {
      this._guiView.renderTrackPitch(this._model.selectedTrack.pitch);
    }
  }, {
    key: "renderTrackVelocity",
    value: function renderTrackVelocity() {
      this._guiView.renderTrackVelocity(this._model.selectedTrack.velocity);
    }
  }, {
    key: "renderTrackGate",
    value: function renderTrackGate() {
      this._guiView.renderTrackGate(this._model.selectedTrack.gate);
    }
  }, {
    key: "renderTrackGateMode",
    value: function renderTrackGateMode(mode) {
      this._guiView.renderTrackGateMode(mode);
    }
  }, {
    key: "renderTrackGateSummingMode",
    value: function renderTrackGateSummingMode() {
      var mode = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this._model.selectedTrack.gateSummingMode;

      this._guiView.renderTrackGateSummingMode(mode);
    }
  }, {
    key: "renderTrackMultiplier",
    value: function renderTrackMultiplier() {
      this._guiView.renderTrackMultiplier(this._model.selectedTrack.durationMultiplier);
    }
  }, {
    key: "renderTrackMute",
    value: function renderTrackMute(trackIndex, mute) {
      if (trackIndex === this._model.selectedTrackIndex) {
        this._guiView.renderTrackMute(mute);
      }

      this._guiView.renderTrackSelectorMute(trackIndex, mute);

      this._launchpadView.renderTrackButton(trackIndex);
    }
  }, {
    key: "renderPatternIndex",
    value: function renderPatternIndex() {
      this._guiView.renderPatternIndex(this._model.selectedPatternIndex);

      this._launchpadView.renderPatternButton(this._model.selectedPatternIndex);
    }
  }, {
    key: "renderPattern",
    value: function renderPattern() {
      this._guiView.renderPattern(this._model.selectedPattern);

      this._launchpadView.render();
    }
  }, {
    key: "renderPatternStart",
    value: function renderPatternStart() {
      this._guiView.renderPatternStart(this._model.selectedPattern.startStepIndex);

      this._launchpadView.render();
    }
  }, {
    key: "renderPatternEnd",
    value: function renderPatternEnd() {
      this._guiView.renderPatternEnd(this._model.selectedPattern.endStepIndex);

      this._launchpadView.render();
    }
  }, {
    key: "renderPatternMute",
    value: function renderPatternMute(patternIndex, mute) {
      if (patternIndex === this._model.selectedPatternIndex) {
        this._guiView.renderPatternMute(mute);
      }

      this._guiView.renderPatternSelectorMute(patternIndex, mute);

      this._launchpadView.renderPatternButton(patternIndex);
    }
  }, {
    key: "renderValue",
    value: function renderValue() {
      var previousValue = this._selectedValue;
      var newValue = this._model.selectedValue;

      if (newValue !== previousValue) {
        this._launchpadView.renderValueButton(previousValue);

        this._launchpadView.renderValueButton(newValue);

        this._guiView.renderValueButton(newValue);

        this._selectedValue = newValue;
      }
    }
  }, {
    key: "renderGrid",
    value: function renderGrid() {
      this._launchpadView.render(); // full render is faster than updating each grid button


      this._guiView.renderGrid();
    }
  }, {
    key: "renderStep",
    value: function renderStep(stepIndex) {
      this._launchpadView.renderStepButton(stepIndex);

      this._guiView.renderStep(stepIndex);
    }
  }, {
    key: "renderClock",
    value: function renderClock() {
      var clock = this._model.clockIndex;
      var track = this._model.selectedTrack;
      var patternIndex = this._model.selectedPatternIndex;
      var previousStepIndex = this._clockIndex;
      var newStepIndex = track.patternStepIndexForClock(clock, patternIndex);

      if (previousStepIndex !== newStepIndex) {
        if (previousStepIndex >= 0) {
          this._launchpadView.renderStepButton(previousStepIndex);

          this._guiView.renderStep(previousStepIndex);
        }

        if (newStepIndex >= 0) {
          this._launchpadView.renderStepButton(newStepIndex);

          this._guiView.renderStep(newStepIndex);
        }

        this._clockIndex = newStepIndex;
      }
    }
  }]);

  return View;
}();

console = new MaxConsole();
var OUTLET$1 = OUTLET;
var outletNames = Object.keys(OUTLET$1);
outlets = outletNames.length;
outletNames.forEach(function (name, index) {
  return setoutletassist(index, name);
});
var model = new Model();
var controller = new Controller(model, new View(model));
function init() {
  controller.initViews();
}
function bang() {
  controller.refreshViews();
}
function reset() {
  controller.reset();
}
function setmodel() {
  for (var _len = arguments.length, data = new Array(_len), _key = 0; _key < _len; _key++) {
    data[_key] = arguments[_key];
  }

  controller.setModel(data);
}
function scale() {
  for (var _len2 = arguments.length, offsets = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
    offsets[_key2] = arguments[_key2];
  }

  controller.setScaleOffsetsRelativeToC(offsets);
}
function root(root) {
  controller.setScaleRoot(root);
}
function duration(duration) {
  controller.setDuration(duration);
}
function modsum(mode) {
  controller.setModulationSummingMode(mode);
}
function modslew(slew) {
  controller.setModulationSlew(slew);
}
function pitch(pitch) {
  controller.setTrackPitch(pitch);
}
function velocity(velocity) {
  controller.setTrackVelocity(velocity);
}
function gate(gate) {
  controller.setTrackGate(gate);
}
function gatemode(mode) {
  controller.setTrackGateMode(mode);
}
function gatesum(mode) {
  controller.setTrackGateSummingMode(mode);
}
function multiplier(multiplier) {
  controller.setTrackMultiplier(multiplier);
}
function trackmute(mute) {
  controller.setTrackMute(mute);
}
function start(stepNumber) {
  controller.setPatternStart(stepNumber - 1);
}
function end(stepNumber) {
  controller.setPatternEnd(stepNumber - 1);
}
function patternmute(mute) {
  controller.setPatternMute(mute);
}
function grid(x, y, enabled) {
  controller.handleGridClick(x, y, enabled);
}
function track(trackIndex) {
  controller.selectTrack(trackIndex);
}
function pattern(patternIndex) {
  controller.selectPattern(patternIndex);
}
function value(value) {
  controller.selectOrToggleValue(value);
}
function lpnote(pitch, velocity) {
  controller.handleLaunchpadNote(pitch, velocity);
}
function lpcc(cc, value) {
  controller.handleLaunchpadCC(cc, value);
}
function note(pitch, velocity) {
  controller.handleTrackNote(pitch, velocity);
}
function cc(cc, value) {
  controller.handleTrackCC(cc, value);
}
function clock(index) {
  controller.handleClockTick(index);
}
function shiftleft() {
  controller.shiftPatternLeft();
}
function shiftright() {
  controller.shiftPatternRight();
}
function shiftup() {
  controller.shiftPatternUp();
}
function shiftdown() {
  controller.shiftPatternDown();
}
function reverse() {
  controller.reversePattern();
}
function random() {
  controller.randomizePattern();
}
function clear() {
  controller.clearPattern();
}
function copy() {
  controller.copyPatternSteps();
}
function paste() {
  controller.pastePatternSteps();
}
function trackreverse() {
  controller.reverseTrack();
}
function trackrandom() {
  controller.randomizeTrack();
}
function trackclear() {
  controller.clearTrack();
}
function trackcopy() {
  controller.copyTrackSteps();
}
function trackpaste() {
  controller.pasteTrackSteps();
}
console.log("________________________________________________________________________________\nreloaded at: ".concat(new Date()));
